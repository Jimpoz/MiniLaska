var searchData=
[
  ['posizionamento_5fpedine_3',['posizionamento_pedine',['../main_8c.html#a993fcc873847ec0e261514c853c052ae',1,'main.c']]]
];
