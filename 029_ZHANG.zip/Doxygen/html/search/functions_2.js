var searchData=
[
  ['scegli_5fmossa_11',['scegli_mossa',['../main_8c.html#a54f95ed8ddc17a0616d8bb884790583e',1,'main.c']]],
  ['stampa_5fscacchiera_12',['stampa_scacchiera',['../main_8c.html#a1c88e8b781147dba000e39974c753dcc',1,'main.c']]]
];
