Gruppo 029

Nome        Cognome     Numero matricola
Jinpeng     Zhang       886854
Danylo      Zubkov      886772
Mirko       Sabir       885169
